<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Illuminate\View\View;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     */
    public function create(): View
    {
        return view('auth.register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
public function store(Request $request): RedirectResponse
{
    // =====================
    // VALIDATION
    // =====================
    $request->validate([
        'nama' => ['required', 'string', 'max:100'],
        'email' => ['required', 'string', 'lowercase', 'email', 'max:100', 'unique:users,email'],
        'password' => ['required', 'confirmed', Rules\Password::defaults()],
    ]);

    // =====================
    // CREATE USER
    // =====================
    $user = User::create([
        'nama' => $request->nama,
        'email' => $request->email,
        'role' => 'mahasiswa', // 🔒 DIPAKSA OLEH SISTEM
        // assign plain password; User model mutator will hash it
        'password' => $request->password,
    ]);

    event(new Registered($user));
    Auth::login($user);

    return redirect()->route('dashboard');
}

}