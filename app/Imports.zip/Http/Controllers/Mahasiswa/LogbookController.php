<?php
namespace App\Http\Controllers\Mahasiswa;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Pkl;
use App\Models\Logbook;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
class LogbookController extends Controller
{
    /**
     * Ambil PKL aktif mahasiswa login
     */
    private function getActivePkl()
    {
        $user = auth()->user();
        if (!$user || !$user->mahasiswa) {
            return null;
        }
        return Pkl::whereHas('pengajuanPkl', function ($q) use ($user) {
                $q->where('id_mhs', $user->mahasiswa->id);
            })
            ->where('status', 'aktif')
            ->latest()
            ->first();
    }
    /**
     * Index: tampilkan semua logbook mahasiswa
     */
    public function index()
    {
        $pkl = $this->getActivePkl();
        $logbooks = $pkl
            ? $pkl->logbooks()->orderBy('tgl', 'desc')->get()
            : collect();
        $hasToday = false;
        if ($pkl) {
            $todayJakarta = Carbon::now('Asia/Jakarta')->toDateString();
            $hasToday = $pkl->logbooks()
                ->whereDate('tgl', $todayJakarta)
                ->exists();
        }
        $tanggalKosong = collect();

        if ($pkl) {

            $mulai = Carbon::parse($pkl->tgl_mulai)->startOfDay();
            $today = Carbon::now('Asia/Jakarta')->startOfDay();

            // semua tanggal PKL
            $period = CarbonPeriod::create($mulai, $today);

            // tanggal yang sudah ada logbook
            $tanggalTerisi = $pkl->logbooks()
                ->pluck('tgl')
                ->map(fn($tgl) => Carbon::parse($tgl)->toDateString())
                ->toArray();

            // cari tanggal yang belum ada logbook
            foreach ($period as $date) {

                if (!in_array($date->toDateString(), $tanggalTerisi)) {
                    $tanggalKosong->push($date->copy());
                }

            }
        }
        return view('mahasiswa.logbook.index', compact(
            'logbooks',
            'hasToday',
            'pkl',
            'tanggalKosong'
        ));
    }
    /**
     * Form tambah logbook
     */
    public function create()
    {
        $pkl = $this->getActivePkl();

        if (!$pkl) {
            return redirect()
                ->route('mahasiswa.logbook.index')
                ->with('warning', 'Belum ada PKL aktif.');
        }

        return view('mahasiswa.logbook.create', compact('pkl'));
    }
    /**
     * Simpan logbook baru
     */
    public function store(Request $request)
    {
        $request->validate([
            'tgl'      => 'required|date',
            'kegiatan' => 'required|string|max:2000',
        ]);
        // Ensure 'tgl' is not after today in Asia/Jakarta timezone
        $todayJakarta = Carbon::now('Asia/Jakarta')->toDateString();
        try {
            $tglInput = Carbon::createFromFormat('Y-m-d', $request->tgl, 'Asia/Jakarta')->toDateString();
        } catch (\Exception $e) {
            return back()->withErrors(['tgl' => 'Format tanggal tidak valid.'])->withInput();
        }
        if ($tglInput > $todayJakarta) {
            return back()->withErrors(['tgl' => 'Tanggal tidak boleh setelah hari ini.'])->withInput();
        }
        $pkl = $this->getActivePkl();
        if (!$pkl) {
            return redirect()
                ->route('mahasiswa.logbook.index')
                ->with('warning', 'Belum ada PKL aktif.');
        }
        if ($pkl->status !== 'aktif') {
            abort(403, 'PKL sudah selesai.');
        }
        $tgl = Carbon::parse($request->tgl);
        $mulai = Carbon::parse($pkl->tgl_mulai);
        // Tidak boleh sebelum mulai PKL
        if ($tgl->lt($mulai)) {
            return back()->with('error', 'Tanggal tidak boleh sebelum masa PKL dimulai.');
        }
        // Cek duplikat tanggal
        $exists = Logbook::where('id_pkl', $pkl->id)
            ->whereDate('tgl', $request->tgl)
            ->exists();
        if ($exists) {
            return back()
                ->withErrors(['tgl' => 'Logbook untuk tanggal tersebut sudah ada.'])
                ->withInput();
        }
        Logbook::create([
            'id_pkl'         => $pkl->id,
            'tgl'            => $request->tgl,
            'kegiatan'       => $request->kegiatan,
            'status_approve' => 'pending',
            'catatan_dosen'  => null,
        ]);
        return redirect()
            ->route('mahasiswa.logbook.index')
            ->with('success', 'Logbook berhasil ditambahkan.');
    }
    /**
     * Edit form
     */
    public function edit(Logbook $logbook)
    {
        $user = auth()->user();
        if (!$user || !$user->mahasiswa) {
            abort(403);
        }
        if ($logbook->pkl->pengajuanPkl->id_mhs !== $user->mahasiswa->id) {
            abort(403, 'Akses ditolak.');
        }
        if ($logbook->pkl->status !== 'aktif') {
            abort(403, 'PKL sudah selesai.');
        }
        if ($logbook->status_approve === 'approved') {
            abort(403, 'Logbook sudah disetujui dan tidak bisa diubah.');
        }
        return view('mahasiswa.logbook.edit', compact('logbook'));
    }
    /**
     * Update logbook
     */
    public function update(Request $request, Logbook $logbook)
    {
        $user = auth()->user();
        if (!$user || !$user->mahasiswa) {
            abort(403);
        }
        if ($logbook->pkl->pengajuanPkl->id_mhs !== $user->mahasiswa->id) {
            abort(403, 'Akses ditolak.');
        }
        if ($logbook->pkl->status !== 'aktif') {
            abort(403, 'PKL sudah selesai.');
        }
        if ($logbook->status_approve === 'approved') {
            abort(403, 'Logbook sudah disetujui dan tidak bisa diubah.');
        }
        $request->validate([
            'tgl'      => 'required|date',
            'kegiatan' => 'required|string|max:2000',
        ]);
        // Ensure 'tgl' is not after today in Asia/Jakarta timezone
        $todayJakarta = Carbon::now('Asia/Jakarta')->toDateString();
        try {
            $tglInput = Carbon::createFromFormat('Y-m-d', $request->tgl, 'Asia/Jakarta')->toDateString();
        } catch (\Exception $e) {
            return back()->withErrors(['tgl' => 'Format tanggal tidak valid.'])->withInput();
        }
        if ($tglInput > $todayJakarta) {
            return back()->withErrors(['tgl' => 'Tanggal tidak boleh setelah hari ini.'])->withInput();
        }
        $pkl = $logbook->pkl;
        $tgl = Carbon::parse($request->tgl);
        $mulai = Carbon::parse($pkl->tgl_mulai);
        $exists = Logbook::where('id_pkl', $pkl->id)
            ->whereDate('tgl', $request->tgl)
            ->where('id', '!=', $logbook->id)
            ->exists();
        if ($exists) {
            return back()->with('error', 'Logbook untuk tanggal tersebut sudah ada.');
        }
        $logbook->update([
            'tgl'            => $request->tgl,
            'kegiatan'       => $request->kegiatan,
            'status_approve' => 'pending',
            'catatan_dosen'  => null,
        ]);
        return redirect()
            ->route('mahasiswa.logbook.index')
            ->with('success', 'Logbook berhasil diperbarui.');
    }
    /**
     * Hapus logbook
     */
    public function destroy(Logbook $logbook)
    {
        $user = auth()->user();
        if (!$user || !$user->mahasiswa) {
            abort(403);
        }
        if ($logbook->pkl->pengajuanPkl->id_mhs !== $user->mahasiswa->id) {
            abort(403, 'Akses ditolak.');
        }
        if ($logbook->status_approve === 'approved') {
            abort(403, 'Logbook yang sudah disetujui tidak dapat dihapus.');
        }
        $logbook->delete();
        return back()->with('success', 'Logbook berhasil dihapus.');
    }
}